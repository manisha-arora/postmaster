<?php
function is_user_logged_in(){
  return isset($_SESSION['is_user_logged_in'])?$_SESSION['is_user_logged_in'][0]:false;
}

function web_root(){
  global $CONFIG;
  return $CONFIG['site']['web_root'];
}

function forward($url){
  header("Location: $url");
  exit;
}

function gateway(){
  if(!is_user_logged_in()){
    forward(web_root());
  }
}
