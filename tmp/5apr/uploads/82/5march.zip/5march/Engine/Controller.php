<?php
class Controller{
  function render($work_area,$data = array()){
    global $CONFIG;
    extract($data);
    include($CONFIG['site']['app_path'].DIRECTORY_SEPARATOR.'views'.DIRECTORY_SEPARATOR.$CONFIG['site']['page_shell']);
  } 
}
