  <table>
    <tr><td>Users:</td><td><select name="user_id">
      <option value="1">Tarun</option>
      <option value="2">Mushi</option>
      <option value="3">Anju</option>
      <option value="4">Priya</option>
      </select></td></tr>
    <tr><td>Subject:</td><td><input type="text" name="subject" value="" /></td></tr>
    <tr><td>Message:</td><td><textarea rows="5" cols="20"></textarea></td></tr>
    <tr><td>Attachment:</td><td><input type="file" name="attachment" /></td></tr>
    <tr><td></td><td><input type="submit" value="Send" name="action" /></td></tr>
  </table> 
