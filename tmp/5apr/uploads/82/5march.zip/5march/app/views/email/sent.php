<table>
    <tr><td><input type="checkbox"></input></td>
	    <td></td>
		<th>To</th>
		<th>Subject</th>
		<th>Date</th>
		<th>Size</th>
	</tr>	
	<?php foreach($email as $val){?>
	<tr><td><input type="checkbox"></input></td>  
        <td><img src="http://ballhankandskein.com/Include/Images/Email-Logo.jpg" height="25" width ="15"></td>
		<td><?php print_r($val->to_id); ?></td>
        <td><?php print_r($val->subject); ?></td>
        <td><?php print_r($val->created_on); }?></td>
        <td> </td>
       
	</tr>
</table>	