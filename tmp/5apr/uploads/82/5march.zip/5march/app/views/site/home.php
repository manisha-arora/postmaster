<img src="http://www.vistaprint.in/any/preview/viewlogo.aspx?cnf=IZAP!+MAIL&icid=829&csid=102&fsid=1&txid=7&tid=1&cfid=0&xcf=&arid=8&msid=0&drid=0&width=140&height=110" height="400" width="400" />
<p>Here we are working on an email project. This will be personal organization's communication channel. So that employees of the organization can communicate with them self.</p>
