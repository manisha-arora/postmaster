<?php
class siteController extends Controller{
  public function index(){
    $data['window_title'] = 'Email project';
    $data['form_title'] = 'Welcome on Zmail';
    $this->render('site/home.php',$data);
  }
  public function login(){
      $form = get_input('form');
      $user = new User();
      $user_array = $user->findUserByUsernameAndPassword($form['username'], $form['password']); 
    if(count($user_array)){
       $_SESSION['is_user_logged_in'] = $user_array;
       forward("index.php?controller=email");
      }
  }

  public function logout(){
    unset($_SESSION['is_user_logged_in']);
    forward(web_root());
  }
}
