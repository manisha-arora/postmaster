<?php
class emailController extends Controller{
  
  public function __construct(){
    gateway();
  }

  public function index(){
    $email = new Email();
    $data['email']=$email->getAll();
    $data['form_title']="Inbox";
    $data['window_title'] = 'My Emails From Index';
    $this->render('email/inbox.php', $data);
  }


  public function compose(){
    $data = array('form_title' => 'Compose new email');
    $this->render('email/compose.php', $data);
  }

  public function inbox(){
    $email=new Email();
    $data['email']=$email->getAll();
    $data['form_title']="Inbox";
    $data['window_title'] = 'My Emails From Index';
    $this->render('email/inbox.php',$data);
  }
  
  public function sent(){
    $email=new Email();
    $data['email']=$email->getAll();
    $data['form_title']="Sent";
    $this->render('email/sent.php', $data);
  }
}
