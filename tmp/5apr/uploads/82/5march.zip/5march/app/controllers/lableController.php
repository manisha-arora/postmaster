<?php
class lableController extends Controller{
  public function index(){
    $lab = new Lable();
    $data['lab'] = $lab;
    $data['window_title'] = 'Lable';
    $this->render('lable/index.php', $data);
  }
 }
