<?php
class userController extends Controller{
  public function index(){
    $user = new User();
    $data['user'] = $user;
    $data['window_title'] = 'User';
    $this->render('user/index.php', $data);
  }
 }
