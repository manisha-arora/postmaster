<?php
class Lable extends Model implements ModelInterface {
  protected $table = 'lables';
  public function __construct(){
    parent::__construct();
  }
}
