<?php
class Email extends Model implements ModelInterface {
  protected $table = 'emails';
  public function __construct(){
    parent::__construct();
  }
}
