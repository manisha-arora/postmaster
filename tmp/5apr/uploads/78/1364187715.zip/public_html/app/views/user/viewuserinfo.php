<form action="index.php?controller=email&action=compose" method="POST">
<?php foreach($user as $val){?> 
<table>
    <tr><td class="row"><img src="<?php echo web_root().'uploads/profile/'.$val->id . '/' . $val->picture; ?>" height="250" width="350"/>
	</td></tr>
	<tr><td align="left"><b> About: </b><?php echo $val->about; ?></td></tr>
	<tr><td align="left"><b> Dob: </b><?php echo $val->dob; ?></td></tr>
	<tr><td class="row"><input type="Submit" value="Send Message" name="compose"></td></tr>
         <?php } ?>	
</table>
</form>	