<table>
<tr><td><a href="index.php?controller=user&action=setting">Edit Profile</a>  |  <a href="index.php?controller=lable">Manage Labels</a></tr>
</table>
