<?php foreach($email as $val){ ?>
<table>
    <tr><td><b>From: </b><?php echo $val->fname . ' ' . $val->lname; ?></td></tr>
	<tr><td><b>To: </b><?php echo get_session_user()->fname . ' ' .get_session_user()->lname ; ?></td></tr>
    <tr><td><b>Message: </b><?php echo $val->body; ?></td></tr>
	<tr><td><b>Attachment:</b></td></tr>
	<tr><td><img src="<?php echo web_root() . 'images/file.jpeg'; ?>" height="50" width="50"></img></td></tr>
	<tr><td><a href="<?php echo web_root() . 'uploads/'. $val->from_id . '/' . $val->attachment;?>"><?php echo $val->attachment; ?></a></td></tr>
	  <?php } ?>
</table>	  