<?php include('_partial.php'); ?>
<form action="index.php?controller=user&action=updateProfile" method="post" enctype="multipart/form-data"/>
<input type="hidden" name="form[id]" value="<?php echo get_session_user()->id; ?>" />
<table>
    <tr><td>
    <img src="<?php echo web_root().'uploads/profile/'.get_session_user()->id .'/'.get_session_user()->picture; ?>"width="200" height="200"/> </td>
	</tr></table>
     <input type="file" name="form[picture]" />
     <br><br>
     <div class="row">
	 <label>First Name:</label></td><td><input type="text" name="form[fname]"        value="<?php echo get_session_user()->fname;?>">
	 
     <label>Last Name:</label></td><td><input type="text" name="form[lname]" value="<?php echo get_session_user()->lname;?>">
	  
	  <label>Dob:</label></td><td><input type="text" name="form[dob]" value="<?php echo get_session_user()->dob;?>">
      
	  <label>About:</label></td><td><textarea rows="7" cols="15" 
	          name="form[about]"><?php echo get_session_user()->about;?></textarea>
	 
	  <label>Address:</label></td><td><input type="text" name="form[address]"        value="<?php echo get_session_user()->address;?>">
     
	  <input type="submit" value="Save" name="form[action]">
</div>  
</form>  
