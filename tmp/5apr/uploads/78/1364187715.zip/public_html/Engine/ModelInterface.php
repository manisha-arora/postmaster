<?php
interface ModelInterface{
  public function getAll();
}
